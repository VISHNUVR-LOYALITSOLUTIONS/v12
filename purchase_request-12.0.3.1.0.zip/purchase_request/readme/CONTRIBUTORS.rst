* Jordi Ballester Alomar <jordi.ballester@eficent.com>
* Jonathan Nemry <jonathan.nemry@acsone.eu>
* Aaron Henriquez <ahenriquez@eficent.com>
* Adrien Peiffer <adrien.peiffer@acsone.eu>
* Lois Rilo <lois.rilo@eficent.com>
* Héctor Villarreal <hector.villarreal@eficent.com>
* Ben Cai <ben.cai@elico-corp.com>
